﻿using System;
using System.Collections.Generic;
using Entiteter;
using Datalager;
using Affärslager;

namespace Presentationslager
{
    class Program
    {
        private SkicenterKontroller skicenterkontroller;

        static void Main(string[] args)
        {
            new Program().Main();
        }

        private Program()
        {
            skicenterkontroller = new SkicenterKontroller();
        }

        /// <summary>
        /// Meny och kontroll av inlogg.
        /// </summary>
        private void Main()
        {
            Console.WriteLine("Välkommen till Skidcentret!");
            bool avsluta = false;
            while (!avsluta)
            {
                try
                {
                    if (Inloggning())
                    {
                        Console.WriteLine("\nDu är nu inloggad, {0}\n Du har rollen: {1}.", skicenterkontroller.Inloggad.Namn, skicenterkontroller.Inloggad.Roll);

                        while (!avsluta)
                        {
                            if (skicenterkontroller.Inloggad.Roll == RollTyp.Admin)
                            {
                                MainMenu();
                                Console.WriteLine("1. Boka Lägenheter --  admin");
                                Console.WriteLine("2. Återlämna ... -- admin");
                                Console.WriteLine("3. Logga ut & avsluta program - admin");
                                Console.Write("Välj ett alternativ: ");
                                int choice = int.Parse(Console.ReadLine());
                                switch (choice)
                                {
                                    case 1:
                                        BokaLägenhet();
                                        break;
                                    case 2:
                                        //ÅterlämnaBok();
                                        break;
                                    case 3:
                                        Console.WriteLine("Tack för idag!");
                                        avsluta = true;
                                        break;
                                    default:
                                        Console.WriteLine("Ogiltigt alternativ. Försök igen.");
                                        MainMenu();
                                        break;
                                }

                            }
                            else if (skicenterkontroller.Inloggad.Roll == RollTyp.Bokningsansvarig)
                            {
                                MainMenu();
                                Console.WriteLine("1. Boka Lägenheter -- Bokningsansvarig");
                                Console.WriteLine("2. Återlämna ...Bokningsansvarig");
                                Console.WriteLine("3. Logga ut & avsluta program -- Bokningsansvarig");
                                Console.Write("Välj ett alternativ: ");
                                int choice = int.Parse(Console.ReadLine());
                                switch (choice)
                                {
                                    case 1:
                                        BokaLägenhet();
                                        break;
                                    case 2:
                                        //ÅterlämnaBok();
                                        break;
                                    case 3:
                                        Console.WriteLine("Tack för idag!");
                                        avsluta = true;
                                        break;
                                    default:
                                        Console.WriteLine("Ogiltigt alternativ. Försök igen.");
                                        MainMenu();
                                        break;
                                }

                            }
                            else if (skicenterkontroller.Inloggad.Roll == RollTyp.Marknadschef)
                            {
                                MainMenu();
                                Console.WriteLine("1. Boka Lägenheter -- Marknadschef");
                                Console.WriteLine("2. Återlämna ...Marknadschef");
                                Console.WriteLine("3. Logga ut & avsluta program -- Marknadschef");
                                Console.Write("Välj ett alternativ: ");
                                int choice = int.Parse(Console.ReadLine());
                                switch (choice)
                                {
                                    case 1:
                                        BokaLägenhet();
                                        break;
                                    case 2:
                                        //ÅterlämnaBok();
                                        break;
                                    case 3:
                                        Console.WriteLine("Tack för idag!");
                                        avsluta = true;
                                        break;
                                    default:
                                        Console.WriteLine("Ogiltigt alternativ. Försök igen.");
                                        MainMenu();
                                        break;
                                }

                            }
                        }

                    }
                    else
                    {
                        Console.WriteLine("Inloggning misslyckad.");
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine("ERROR: " + e.Message);
                }
            }
        }


        /// <summary>
        /// Inloggningen. Kontrollerar att det är korrekt.
        /// </summary>
        /// <returns></returns>
        private bool Inloggning()
        {


            Console.Write("Skriv ditt användarnamn: ");
            string användarnamn = Console.ReadLine();

            Console.Write("Skriv ditt lösenord: ");
            string lösenord = Console.ReadLine();

            return skicenterkontroller.LoggaIn(användarnamn, lösenord);
        }


        private void MainMenu()
        {
            Console.WriteLine("\n\nHuvudmeny:");
        }

        /// <summary>
        /// Boka en bok.En bokning per bok.
        /// </summary>
        private void BokaLägenhet()
        {
            Console.WriteLine();
            string nrToParse = "";
            int nr;
            while (!int.TryParse(nrToParse, out nr))
            {
                Console.Write("Skriv in kundNr: ");
                nrToParse = Console.ReadLine();
            }
            Privatkund Beställare = skicenterkontroller.KontrolleraKund(nr);
            Console.WriteLine("Bokning kommer göras för: {0}", Beställare.Namn);

            Console.WriteLine();
            Console.WriteLine("Från när ska en lägenhet bokas?");
            Console.Write("Mata in i detta format, Jan 1, 2023: ");
            DateTime frånTid = DateTime.Parse(Console.ReadLine());
            Console.WriteLine("Till när ska lägenheten vara bokad?");
            Console.Write("Mata in i detta format, Jan 1, 2023: ");
            DateTime tillTid = DateTime.Parse(Console.ReadLine());

            Console.WriteLine();
            IList<Lägenhet> tillgänglig = skicenterkontroller.HämtaTillgängligaKonferensrum();
            int i = 1;
            foreach (Lägenhet lägenhet in tillgänglig)
            {
                Console.Write("{0}. ", i++);
                Skriv(lägenhet);
            }
            Console.WriteLine("\nVilken lägenhet ska bokas?");
            string antalToParse = "";
            int antal;
            while (!int.TryParse(antalToParse, out antal) || !(0 < antal && antal <= tillgänglig.Count))
            {
                Console.Write("Skriv lägenhetens nummer: ");
                antalToParse = Console.ReadLine();
            }
            Bokning nyBokning = skicenterkontroller.BokaLägenhet(tillgänglig[antal - 1], frånTid, tillTid);
            Skriv(nyBokning);
        }

        ///// <summary>
        ///// Lämna tillbaka lånad boken. Endast en bok återlämnas i taget.
        ///// </summary>
        //private void ÅterlämnaBok()
        //{
        //    Console.WriteLine();
        //    string nrToParse = "";
        //    int nr;
        //    while (!int.TryParse(nrToParse, out nr))
        //    {
        //        Console.Write("Skriv in bokningsnumret: ");
        //        nrToParse = Console.ReadLine();
        //    }
        //    Bokning attÅterlämna = bibliotekKontroller.KontrollaBokningNr(nr);
        //    Console.WriteLine("Du återlämnar " + attÅterlämna.Bok.Titel + ".");

        //    Faktura faktura = bibliotekKontroller.ÅterlämnaBok(attÅterlämna);
        //    Console.WriteLine("\n\tÅterlämnad bok: " + attÅterlämna.Bok.Titel + "\n\tBokad av: " + attÅterlämna.Medlem.Namn);
        //    Console.WriteLine("\tDen var bokad från: " + faktura.Bokning.FaktiskUtlämningstid +
        //        "\n\tDen var bokad till: " + faktura.FaktiskÅterlämingstid);
        //    Console.WriteLine("\n\tBetalningsskyldig: " + faktura.TotalPris + " kr.");
        //}

     

        private void Skriv(Lägenhet lägenhet)
        {
            Console.WriteLine("  {0}", lägenhet.Beskrivning);
        }

        private void Skriv(Bokning bokning)
        {
            //Console.WriteLine("\n\tBeskrivning: {0}\n\tBokad till: {1}\n\tÅterlämningstid: {2}\n\tBokningsnummer: {3}", bokning.Lägenhet.Beskrivning,
            //    bokning.Privatkund.Namn, bokning.TilltänktaÅterlämningstid, bokning.BokningsID);
            Console.WriteLine(" RegNo: {0} reserved on {1} by {2}.",
                             bokning.Lägenhet.LägenhetsID, bokning.TilltänktUtlämningstid, bokning.Privatkund.Namn);
        }
        private SkicenterKontroller skicenterKontroller;
    }
}
