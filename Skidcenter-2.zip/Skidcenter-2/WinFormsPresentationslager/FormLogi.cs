﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Entiteter;
using Datalager;
using Affärslager;

namespace WinFormsPresentationslager
{

    public partial class FormLogi : Form
    {
        private SkicenterKontroller skicenterKontroller;
        private UnitOfWork unitOfWork;
        private Anställd Inloggad;
        public FormLogi(SkicenterKontroller lKontroller, Anställd inloggad)
        {
            InitializeComponent();
            this.skicenterKontroller = lKontroller;
            this.Inloggad = inloggad;
        }

        private void btnBokaLägenhet_Click(object sender, EventArgs e)
        {
            FormBokaLägenhet formBokaLägenhet = new FormBokaLägenhet(skicenterKontroller, Inloggad);
            formBokaLägenhet.Show();
        }

        private void btnAvBokaLägenhet_Click(object sender, EventArgs e)
        {
            FormAvBokaLägenhet formAvBokaBok = new FormAvBokaLägenhet(skicenterKontroller, Inloggad);
            formAvBokaBok.Show();
        }
        private void btnAvsluta_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnBokaKonferens_Click(object sender, EventArgs e)
        {
            FormBokaKonferens formBokaKonferens = new FormBokaKonferens(skicenterKontroller, Inloggad);
            formBokaKonferens.Show();
        }
    }
}
