﻿
namespace WinFormsPresentationslager
{
    partial class FormAvBokaLägenhet
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblBokningnr = new System.Windows.Forms.Label();
            this.tbxBokningnr = new System.Windows.Forms.TextBox();
            this.btnAvboka = new System.Windows.Forms.Button();
            //this.lblDuAvbokar = new System.Windows.Forms.Label();
            this.lblAvBokadLägenhet = new System.Windows.Forms.Label();
            this.lblBokadTillPerson = new System.Windows.Forms.Label();
            //this.lblBokadFrån = new System.Windows.Forms.Label();
            //this.lblBokadTill = new System.Windows.Forms.Label();
            //this.lblBetalningsskyldig = new System.Windows.Forms.Label();
            this.btnAvsluta = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblBokningnr
            // 
            this.lblBokningnr.AutoSize = true;
            this.lblBokningnr.Location = new System.Drawing.Point(148, 40);
            this.lblBokningnr.Name = "lblBokningnr";
            this.lblBokningnr.Size = new System.Drawing.Size(127, 20);
            this.lblBokningnr.TabIndex = 0;
            this.lblBokningnr.Text = "Bokningsnummer:";
            // 
            // tbxBokningnr
            // 
            this.tbxBokningnr.Location = new System.Drawing.Point(281, 37);
            this.tbxBokningnr.Name = "tbxBokningnr";
            this.tbxBokningnr.Size = new System.Drawing.Size(125, 27);
            this.tbxBokningnr.TabIndex = 1;
            // 
            // btnAvboka
            // 
            this.btnAvboka.Location = new System.Drawing.Point(423, 35);
            this.btnAvboka.Name = "btnAvboka";
            this.btnAvboka.Size = new System.Drawing.Size(94, 29);
            this.btnAvboka.TabIndex = 2;
            this.btnAvboka.Text = "Avboka";
            this.btnAvboka.UseVisualStyleBackColor = true;
            this.btnAvboka.Click += new System.EventHandler(this.btnAvboka_Click);
            // 
            //// lblDuAvbokar
            //// 
            //this.lblDuAvbokar.AutoSize = true;
            //this.lblDuAvbokar.Location = new System.Drawing.Point(63, 127);
            //this.lblDuAvbokar.Name = "lblDuAvbokar";
            //this.lblDuAvbokar.Size = new System.Drawing.Size(111, 20);
            //this.lblDuAvbokar.TabIndex = 3;
            //this.lblDuAvbokar.Text = "Du avbokar: ";
            // 
            // lblAvBokadLägenhet
            // 
            this.lblAvBokadLägenhet.AutoSize = true;
            this.lblAvBokadLägenhet.Location = new System.Drawing.Point(63, 204);
            this.lblAvBokadLägenhet.Name = "lblAvBokadLägenhet";
            this.lblAvBokadLägenhet.Size = new System.Drawing.Size(123, 20);
            this.lblAvBokadLägenhet.TabIndex = 4;
            this.lblAvBokadLägenhet.Text = "Avbokad Lägenhet: ";
            // 
            // lblBokadTill
            // 
            this.lblBokadTillPerson.AutoSize = true;
            this.lblBokadTillPerson.Location = new System.Drawing.Point(63, 228);
            this.lblBokadTillPerson.Name = "lblBokadTillPerson";
            this.lblBokadTillPerson.Size = new System.Drawing.Size(77, 20);
            this.lblBokadTillPerson.TabIndex = 5;
            this.lblBokadTillPerson.Text = "Bokad Till Person: ";
            // 
            // lblBokadFrån
            //// 
            //this.lblBokadFrån.AutoSize = true;
            //this.lblBokadFrån.Location = new System.Drawing.Point(63, 269);
            //this.lblBokadFrån.Name = "lblBokadFrån";
            //this.lblBokadFrån.Size = new System.Drawing.Size(88, 20);
            //this.lblBokadFrån.TabIndex = 6;
            //this.lblBokadFrån.Text = "Bokad från: ";
            //// 
            //// lblBokadTill
            //// 
            //this.lblBokadTill.AutoSize = true;
            //this.lblBokadTill.Location = new System.Drawing.Point(63, 293);
            //this.lblBokadTill.Name = "lblBokadTill";
            //this.lblBokadTill.Size = new System.Drawing.Size(75, 20);
            //this.lblBokadTill.TabIndex = 7;
            //this.lblBokadTill.Text = "Bokad till:";
            //// 
            //// lblBetalningsskyldig
            //// 
            //this.lblBetalningsskyldig.AutoSize = true;
            //this.lblBetalningsskyldig.Location = new System.Drawing.Point(63, 332);
            //this.lblBetalningsskyldig.Name = "lblBetalningsskyldig";
            //this.lblBetalningsskyldig.Size = new System.Drawing.Size(131, 20);
            //this.lblBetalningsskyldig.TabIndex = 8;
            //this.lblBetalningsskyldig.Text = "Betalningsskyldig: ";
            // 
            // btnAvsluta
            // 
            this.btnAvsluta.Location = new System.Drawing.Point(526, 387);
            this.btnAvsluta.Name = "btnAvsluta";
            this.btnAvsluta.Size = new System.Drawing.Size(238, 29);
            this.btnAvsluta.TabIndex = 9;
            this.btnAvsluta.Text = "Avsluta";
            this.btnAvsluta.UseVisualStyleBackColor = true;
            this.btnAvsluta.Click += new System.EventHandler(this.btnAvsluta_Click);
            // 
            // FormAvBokaLägenhet
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnAvsluta);
            //this.Controls.Add(this.lblBetalningsskyldig);
            //this.Controls.Add(this.lblBokadTill);
            //this.Controls.Add(this.lblBokadFrån);
            this.Controls.Add(this.lblBokadTillPerson);
            this.Controls.Add(this.lblAvBokadLägenhet);
            //this.Controls.Add(this.lblDuAvbokar);
            this.Controls.Add(this.btnAvboka);
            this.Controls.Add(this.tbxBokningnr);
            this.Controls.Add(this.lblBokningnr);
            this.Name = "FormAvBokaLägenhet";
            this.Text = "Avboka Lägenhet";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblBokningnr;
        private System.Windows.Forms.TextBox tbxBokningnr;
        private System.Windows.Forms.Button btnAvboka;
        private System.Windows.Forms.Label lblDuAvbokar;
        private System.Windows.Forms.Label lblAvBokadLägenhet;
        private System.Windows.Forms.Label lblBokadTillPerson;
        //private System.Windows.Forms.Label lblBokadFrån;
        //private System.Windows.Forms.Label lblBokadTill;
        //private System.Windows.Forms.Label lblBetalningsskyldig;
        private System.Windows.Forms.Button btnAvsluta;
    }
}