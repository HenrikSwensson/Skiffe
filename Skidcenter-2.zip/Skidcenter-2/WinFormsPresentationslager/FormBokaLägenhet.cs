﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Entiteter;
using Datalager;
using Affärslager;

namespace WinFormsPresentationslager
{
    public partial class FormBokaLägenhet : Form
    {
        private SkicenterKontroller skicenterKontroller;
        private UnitOfWork unitOfWork;
        private Lägenhet ValdLägenhet;
        private DateTime FrånTid;
        private DateTime TillTid;
        private Anställd Inloggad;
        private IList<Lägenhet> tillgängliga;

        public FormBokaLägenhet(SkicenterKontroller lKontroller, Anställd inloggad)
        {
            InitializeComponent();
            this.skicenterKontroller = lKontroller;
            this.Inloggad = inloggad;
        }

        private void RefreshListBox()
        {
            tillgängliga = skicenterKontroller.HämtaTillgängligaLägenheter();
            foreach (Lägenhet l in tillgängliga)
            {
                //listBoxTillgängligaLägenheter.Items.Add(l.Beskrivning);
                string listItem = $" Artikelnummer: {l.ArtikelNr},  {l.Beskrivning} , Pris per dygn: {l.Pris} ";

            // Lägg till strängen i ListBox
            listBoxTillgängligaLägenheter.Items.Add(listItem);
            }

        }

    

        private void btnBokaMarkeradLägenhet_Click(object sender, EventArgs e)

        {
            string nrToParse = "";
            int nr;
            while (!int.TryParse(nrToParse, out nr))
            {
                nrToParse = tbxMedlemsNr.Text;
            }
            Privatkund Beställare = skicenterKontroller.KontrolleraKund(nr);

            if (listBoxTillgängligaLägenheter.SelectedItem != null)
            {
                BokningLägenhet bg = skicenterKontroller.BokaLägenhet(ValdLägenhet, FrånTid, TillTid);

                lblBokadLägenhet.Text = "Bokad lägenhet: " + bg.Lägenhet.Beskrivning;
                lblBokadAv.Text = "Bokad till kund: " + bg.Privatkund.Namn + " " + bg.Privatkund.Efternamn + "  TelefonNr:   " + bg.Privatkund.TlfNr + "   Epost:  " + bg.Privatkund.Epostadress;
                lblBokningNr.Text = "Bokningsnummer: " + bg.BokningsID;
                lblÅterlämnasSenast.Text = "Utcheckning senast: " + bg.TilltänktaÅterlämningstid;
            }
            //RefreshListBox();
        }



        private void btnNästaBoka_Click(object sender, EventArgs e)
        {
         

            FrånTid = calBokaFrån.SelectionStart;
            TillTid = calBokaTill.SelectionEnd;

            RefreshListBox();
        }

        private void btnAvsluta_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void listBoxTillgängligaLägenheter_Click(object sender, EventArgs e)
        {
            ValdLägenhet = tillgängliga[listBoxTillgängligaLägenheter.SelectedIndex];
        }

        private void calBokaFrån_DateSelected(object sender, DateRangeEventArgs e)
        {
            FrånTid = calBokaFrån.SelectionStart;
        }

        private void monthCalendar1_DateSelected(object sender, DateRangeEventArgs e)
        {
            TillTid = calBokaTill.SelectionEnd;
        }
    }
}
