﻿﻿﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Affärslager;
using Entiteter;

namespace WinFormsPresentationslager
{
    public partial class FormInloggning : Form
    {
        private SkicenterKontroller skicenterKontroller;

        public FormInloggning(SkicenterKontroller bKontroller)
        {
            InitializeComponent();
            this.skicenterKontroller = bKontroller;
        }

        private void btnLoggaIn_Click(object sender, EventArgs e)
        {
            string användarnamn = tbxAnställningNr.Text;  // Antaget att du har en TextBox som heter txtAnvändarnamn
            string lösenord = tbxLösenord.Text;  // Antaget att du har en TextBox som heter txtLösenord

            bool loggadIn = skicenterKontroller.LoggaIn(användarnamn, lösenord);  // Anropar din ursprungliga LoggaIn metod i SkicenterKontroller

            if (loggadIn)
            {
                Anställd inloggad = skicenterKontroller.HämtaInloggadAnställd();
                MessageBox.Show($"Välkommen! Din roll är: {inloggad.Roll}");
                FormMeny formMeny = new FormMeny(skicenterKontroller);
                formMeny.Show();
            }
            else
            {
                MessageBox.Show("Inloggning misslyckades!");  // Visar en dialogruta om inloggningen misslyckas
            }
        }


        private void btnAvsluta_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }
}