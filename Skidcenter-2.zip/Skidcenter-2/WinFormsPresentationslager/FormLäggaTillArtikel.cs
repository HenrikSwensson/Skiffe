﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Entiteter;
using Datalager;
using Affärslager;

namespace WinFormsPresentationslager
{
    public partial class FormLäggaTillArtikel : Form
    {
        private SkicenterKontroller skicenterKontroller;
        private UnitOfWork unitOfWork;
        private Anställd Inloggad;
        public FormLäggaTillArtikel(SkicenterKontroller lKontroller, Anställd inloggad)
        {
            InitializeComponent();
            this.skicenterKontroller = lKontroller;
            this.Inloggad = inloggad;
        }
    }
}
