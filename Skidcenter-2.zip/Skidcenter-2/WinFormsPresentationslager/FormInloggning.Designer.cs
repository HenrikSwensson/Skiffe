﻿
namespace WinFormsPresentationslager
{
    partial class FormInloggning
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblAnställningNr = new System.Windows.Forms.Label();
            this.lblLösenord = new System.Windows.Forms.Label();
            this.tbxAnställningNr = new System.Windows.Forms.TextBox();
            this.tbxLösenord = new System.Windows.Forms.TextBox();
            this.btnLoggaIn = new System.Windows.Forms.Button();
            this.btnAvsluta = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblAnställningNr
            // 
            this.lblAnställningNr.AutoSize = true;
            this.lblAnställningNr.Location = new System.Drawing.Point(79, 70);
            this.lblAnställningNr.Name = "lblAnställningNr";
            this.lblAnställningNr.Size = new System.Drawing.Size(119, 15);
            this.lblAnställningNr.TabIndex = 0;
            this.lblAnställningNr.Text = "Användarnamn: ";
            // 
            // lblLösenord
            // 
            this.lblLösenord.AutoSize = true;
            this.lblLösenord.Location = new System.Drawing.Point(79, 104);
            this.lblLösenord.Name = "lblLösenord";
            this.lblLösenord.Size = new System.Drawing.Size(62, 15);
            this.lblLösenord.TabIndex = 1;
            this.lblLösenord.Text = "Lösenord: ";
            // 
            // tbxAnställningNr
            // 
            this.tbxAnställningNr.Location = new System.Drawing.Point(211, 68);
            this.tbxAnställningNr.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbxAnställningNr.Name = "tbxAnställningNr";
            this.tbxAnställningNr.Size = new System.Drawing.Size(160, 23);
            this.tbxAnställningNr.TabIndex = 2;
            // 
            // tbxLösenord
            // 
            this.tbxLösenord.Location = new System.Drawing.Point(211, 102);
            this.tbxLösenord.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbxLösenord.Name = "tbxLösenord";
            this.tbxLösenord.Size = new System.Drawing.Size(160, 23);
            this.tbxLösenord.TabIndex = 3;
            // 
            // btnLoggaIn
            // 
            this.btnLoggaIn.Location = new System.Drawing.Point(211, 127);
            this.btnLoggaIn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnLoggaIn.Name = "btnLoggaIn";
            this.btnLoggaIn.Size = new System.Drawing.Size(159, 23);
            this.btnLoggaIn.TabIndex = 4;
            this.btnLoggaIn.Text = "Logga in";
            this.btnLoggaIn.UseVisualStyleBackColor = true;
            this.btnLoggaIn.Click += new System.EventHandler(this.btnLoggaIn_Click);
            // 
            // btnAvsluta
            // 
            this.btnAvsluta.Location = new System.Drawing.Point(340, 183);
            this.btnAvsluta.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnAvsluta.Name = "btnAvsluta";
            this.btnAvsluta.Size = new System.Drawing.Size(116, 22);
            this.btnAvsluta.TabIndex = 5;
            this.btnAvsluta.Text = "Avsluta";
            this.btnAvsluta.UseVisualStyleBackColor = true;
            this.btnAvsluta.Click += new System.EventHandler(this.btnAvsluta_Click);
            // 
            // FormInloggning
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(467, 214);
            this.Controls.Add(this.btnAvsluta);
            this.Controls.Add(this.btnLoggaIn);
            this.Controls.Add(this.tbxLösenord);
            this.Controls.Add(this.tbxAnställningNr);
            this.Controls.Add(this.lblLösenord);
            this.Controls.Add(this.lblAnställningNr);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "FormInloggning";
            this.Text = "Logga in";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblAnställningNr;
        private System.Windows.Forms.Label lblLösenord;
        private System.Windows.Forms.TextBox tbxAnställningNr;
        private System.Windows.Forms.TextBox tbxLösenord;
        private System.Windows.Forms.Button btnLoggaIn;
        private System.Windows.Forms.Button btnAvsluta;
    }
}