﻿
namespace WinFormsPresentationslager
{
    partial class FormBokaLägenhet
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblMedlemNr = new System.Windows.Forms.Label();
            this.tbxMedlemsNr = new System.Windows.Forms.TextBox();
            this.btnNästaBoka = new System.Windows.Forms.Button();
            this.btnBokaMarkeradLägenhet = new System.Windows.Forms.Button();
            this.btnAvsluta = new System.Windows.Forms.Button();
            this.listBoxTillgängligaLägenheter = new System.Windows.Forms.ListBox();
            this.lblBokadLägenhet = new System.Windows.Forms.Label();
            this.lblBokadAv = new System.Windows.Forms.Label();
            this.lblÅterlämnasSenast = new System.Windows.Forms.Label();
            this.lblBokningNr = new System.Windows.Forms.Label();
            this.lblBokaFrån = new System.Windows.Forms.Label();
            this.calBokaFrån = new System.Windows.Forms.MonthCalendar();
            this.label1 = new System.Windows.Forms.Label();
            this.calBokaTill = new System.Windows.Forms.MonthCalendar();
            this.SuspendLayout();
            // 
            // lblMedlemNr
            // 
            this.lblMedlemNr.AutoSize = true;
            this.lblMedlemNr.Location = new System.Drawing.Point(29, 204);
            this.lblMedlemNr.Name = "lblMedlemNr";
            this.lblMedlemNr.Size = new System.Drawing.Size(108, 15);
            this.lblMedlemNr.TabIndex = 0;
            this.lblMedlemNr.Text = "Medlemsnummer: ";
            // 
            // tbxMedlemsNr
            // 
            this.tbxMedlemsNr.Location = new System.Drawing.Point(143, 201);
            this.tbxMedlemsNr.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbxMedlemsNr.Name = "tbxMedlemsNr";
            this.tbxMedlemsNr.Size = new System.Drawing.Size(224, 23);
            this.tbxMedlemsNr.TabIndex = 1;
            // 
            // btnNästaBoka
            // 
            this.btnNästaBoka.Location = new System.Drawing.Point(553, 180);
            this.btnNästaBoka.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnNästaBoka.Name = "btnNästaBoka";
            this.btnNästaBoka.Size = new System.Drawing.Size(82, 22);
            this.btnNästaBoka.TabIndex = 2;
            this.btnNästaBoka.Text = "Nästa";
            this.btnNästaBoka.UseVisualStyleBackColor = true;
            this.btnNästaBoka.Click += new System.EventHandler(this.btnNästaBoka_Click);
            // 
            // btnBokaMarkeradLägenhet
            // 
            this.btnBokaMarkeradLägenhet.Location = new System.Drawing.Point(448, 356);
            this.btnBokaMarkeradLägenhet.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnBokaMarkeradLägenhet.Name = "btnBokaMarkeradLägenhet";
            this.btnBokaMarkeradLägenhet.Size = new System.Drawing.Size(201, 25);
            this.btnBokaMarkeradLägenhet.TabIndex = 4;
            this.btnBokaMarkeradLägenhet.Text = "Boka markerad Lägenhet";
            this.btnBokaMarkeradLägenhet.UseVisualStyleBackColor = true;
            this.btnBokaMarkeradLägenhet.Click += new System.EventHandler(this.btnBokaMarkeradLägenhet_Click);
            // 
            // btnAvsluta
            // 
            this.btnAvsluta.Location = new System.Drawing.Point(482, 435);
            this.btnAvsluta.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnAvsluta.Name = "btnAvsluta";
            this.btnAvsluta.Size = new System.Drawing.Size(167, 22);
            this.btnAvsluta.TabIndex = 5;
            this.btnAvsluta.Text = "Avsluta/Skriv ut";
            this.btnAvsluta.UseVisualStyleBackColor = true;
            this.btnAvsluta.Click += new System.EventHandler(this.btnAvsluta_Click);
            // 
            // listBoxTillgängligaLägenheter
            // 
            this.listBoxTillgängligaLägenheter.FormattingEnabled = true;
            this.listBoxTillgängligaLägenheter.ItemHeight = 15;
            this.listBoxTillgängligaLägenheter.Location = new System.Drawing.Point(45, 228);
            this.listBoxTillgängligaLägenheter.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.listBoxTillgängligaLägenheter.Name = "listBoxTillgängligaLägenheter";
            this.listBoxTillgängligaLägenheter.Size = new System.Drawing.Size(605, 124);
            this.listBoxTillgängligaLägenheter.TabIndex = 6;
            this.listBoxTillgängligaLägenheter.Click += new System.EventHandler(this.listBoxTillgängligaLägenheter_Click);
            // 
            // lblBokadLägenhet
            // 
            this.lblBokadLägenhet.AutoSize = true;
            this.lblBokadLägenhet.Location = new System.Drawing.Point(45, 393);
            this.lblBokadLägenhet.Name = "lblBokadLägenhet";
            this.lblBokadLägenhet.Size = new System.Drawing.Size(98, 15);
            this.lblBokadLägenhet.TabIndex = 7;
            this.lblBokadLägenhet.Text = "Bokad Lägenhet: ";
            // 
            // lblBokadAv
            // 
            this.lblBokadAv.AutoSize = true;
            this.lblBokadAv.Location = new System.Drawing.Point(45, 408);
            this.lblBokadAv.Name = "lblBokadAv";
            this.lblBokadAv.Size = new System.Drawing.Size(92, 15);
            this.lblBokadAv.TabIndex = 8;
            this.lblBokadAv.Text = "Bokad till kund: ";
            // 
            // lblÅterlämnasSenast
            // 
            this.lblÅterlämnasSenast.AutoSize = true;
            this.lblÅterlämnasSenast.Location = new System.Drawing.Point(45, 438);
            this.lblÅterlämnasSenast.Name = "lblÅterlämnasSenast";
            this.lblÅterlämnasSenast.Size = new System.Drawing.Size(116, 15);
            this.lblÅterlämnasSenast.TabIndex = 9;
            this.lblÅterlämnasSenast.Text = "Utcheckning senast: ";
            // 
            // lblBokningNr
            // 
            this.lblBokningNr.AutoSize = true;
            this.lblBokningNr.Location = new System.Drawing.Point(45, 423);
            this.lblBokningNr.Name = "lblBokningNr";
            this.lblBokningNr.Size = new System.Drawing.Size(108, 15);
            this.lblBokningNr.TabIndex = 10;
            this.lblBokningNr.Text = "Bokningsnummer: ";
            // 
            // lblBokaFrån
            // 
            this.lblBokaFrån.AutoSize = true;
            this.lblBokaFrån.Location = new System.Drawing.Point(29, 9);
            this.lblBokaFrån.Name = "lblBokaFrån";
            this.lblBokaFrån.Size = new System.Drawing.Size(63, 15);
            this.lblBokaFrån.TabIndex = 11;
            this.lblBokaFrån.Text = "Boka från: ";
            // 
            // calBokaFrån
            // 
            this.calBokaFrån.Location = new System.Drawing.Point(94, 9);
            this.calBokaFrån.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.calBokaFrån.Name = "calBokaFrån";
            this.calBokaFrån.TabIndex = 13;
            this.calBokaFrån.DateSelected += new System.Windows.Forms.DateRangeEventHandler(this.calBokaFrån_DateSelected);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(349, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 15);
            this.label1.TabIndex = 14;
            this.label1.Text = "Boka till: ";
            // 
            // calBokaTill
            // 
            this.calBokaTill.Location = new System.Drawing.Point(415, 9);
            this.calBokaTill.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.calBokaTill.Name = "calBokaTill";
            this.calBokaTill.TabIndex = 15;
            this.calBokaTill.DateSelected += new System.Windows.Forms.DateRangeEventHandler(this.monthCalendar1_DateSelected);
            // 
            // FormBokaLägenhet
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(701, 466);
            this.Controls.Add(this.calBokaTill);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.calBokaFrån);
            this.Controls.Add(this.lblBokaFrån);
            this.Controls.Add(this.lblBokningNr);
            this.Controls.Add(this.lblÅterlämnasSenast);
            this.Controls.Add(this.lblBokadAv);
            this.Controls.Add(this.lblBokadLägenhet);
            this.Controls.Add(this.listBoxTillgängligaLägenheter);
            this.Controls.Add(this.btnAvsluta);
            this.Controls.Add(this.btnBokaMarkeradLägenhet);
            this.Controls.Add(this.btnNästaBoka);
            this.Controls.Add(this.tbxMedlemsNr);
            this.Controls.Add(this.lblMedlemNr);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "FormBokaLägenhet";
            this.Text = "Boka Lägenhet";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblMedlemNr;
        private System.Windows.Forms.TextBox tbxMedlemsNr;
        private System.Windows.Forms.Button btnNästaBoka;
        private System.Windows.Forms.Button btnBokaMarkeradLägenhet;
        private System.Windows.Forms.Button btnAvsluta;
        private System.Windows.Forms.ListBox listBoxTillgängligaLägenheter;
        private System.Windows.Forms.Label lblBokadLägenhet;
        private System.Windows.Forms.Label lblBokadAv;
        private System.Windows.Forms.Label lblÅterlämnasSenast;
        private System.Windows.Forms.Label lblBokningNr;
        private System.Windows.Forms.Label lblBokaFrån;
        private System.Windows.Forms.MonthCalendar calBokaFrån;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.MonthCalendar calBokaTill;
    }
}