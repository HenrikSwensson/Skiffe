﻿using Affärslager;
using Entiteter;
using System.Windows.Forms;
using System;



namespace WinFormsPresentationslager
{
    partial class LäggTillFöretagskund
    {
        private SkicenterKontroller controller;

        public LäggTillFöretagskund(SkicenterKontroller controller)
        {
            InitializeComponent();
            this.controller = controller;

            btnLäggTill.Click += new EventHandler(this.btnLäggTill_Click);
        }

        private void btnLäggTill_Click(object sender, EventArgs e)
        {
            Foretagskund nyFöretagskund = new Foretagskund();
            nyFöretagskund.Namn = tbxFöretagNm.Text;
            nyFöretagskund.OrgNr = tbxOrganisationNr.Text;
            nyFöretagskund.KontaktPerson = tbxKontaktPers.Text;
            nyFöretagskund.TlfNr = tbxTelefonNr.Text;
            nyFöretagskund.Epostadress = tbxEpostAdr.Text;

            // Anropa metoden LaggTillForetagskund() i din SkicenterKontroller-instans.
            SkicenterKontroller controller = new SkicenterKontroller();
            if (controller.LaggTillForetagskund(nyFöretagskund))
            {
                // Företagskunden har sparats.
                MessageBox.Show("Företagskund har lagts till.");
            }
            else
            {
                // Något gick fel.
                MessageBox.Show("Något gick fel.");
            }
        }
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        public string GetOrganisationNr()
        {
            return tbxOrganisationNr.Text;
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblInfo = new System.Windows.Forms.Label();
            this.lblFöretagNm = new System.Windows.Forms.Label();
            this.lblOrganisationNr = new System.Windows.Forms.Label();
            this.lblKontaktPers = new System.Windows.Forms.Label();
            this.lblTelefonNr = new System.Windows.Forms.Label();
            this.lblEpostAdr = new System.Windows.Forms.Label();
            this.tbxFöretagNm = new System.Windows.Forms.TextBox();
            this.tbxOrganisationNr = new System.Windows.Forms.TextBox();
            this.tbxKontaktPers = new System.Windows.Forms.TextBox();
            this.tbxTelefonNr = new System.Windows.Forms.TextBox();
            this.tbxEpostAdr = new System.Windows.Forms.TextBox();
            this.btnLäggTill = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // Information
            this.lblInfo.AutoSize = true;
            this.lblInfo.Location = new System.Drawing.Point(169, 0);
            this.lblInfo.Name = "lblInfo";
            this.lblInfo.Size = new System.Drawing.Size(188, 20);
            this.lblInfo.Text = "Fyll I relevant information";
            // 
            // lblFöretagNm
            // 
            this.lblFöretagNm.AutoSize = true;
            this.lblFöretagNm.Location = new System.Drawing.Point(79, 20);
            this.lblFöretagNm.Name = "lblFöretagNm";
            this.lblFöretagNm.Size = new System.Drawing.Size(119, 15);
            this.lblFöretagNm.TabIndex = 0;
            this.lblFöretagNm.Text = "Företagsnamn: ";
            // 
            // lblOrganisationNr
            // 
            this.lblOrganisationNr.AutoSize = true;
            this.lblOrganisationNr.Location = new System.Drawing.Point(79, 50);
            this.lblOrganisationNr.Name = "lblOrganisationNr";
            this.lblOrganisationNr.Size = new System.Drawing.Size(62, 15);
            this.lblOrganisationNr.TabIndex = 1;
            this.lblOrganisationNr.Text = "Org.nr: ";
            // 
            // lblKontaktPers
            // 
            this.lblKontaktPers.AutoSize = true;
            this.lblKontaktPers.Location = new System.Drawing.Point(79, 80);
            this.lblKontaktPers.Name = "lblKontaktPers";
            this.lblKontaktPers.Size = new System.Drawing.Size(62, 15);
            this.lblKontaktPers.TabIndex = 2;
            this.lblKontaktPers.Text = "Kontaktperson: ";
            // 
            // lblTelefonNr
            // 
            this.lblTelefonNr.AutoSize = true;
            this.lblTelefonNr.Location = new System.Drawing.Point(79, 110);
            this.lblTelefonNr.Name = "lblTelefonNr";
            this.lblTelefonNr.Size = new System.Drawing.Size(62, 15);
            this.lblTelefonNr.TabIndex = 3;
            this.lblTelefonNr.Text = "Telefonnummer: ";
            // 
            // lblEpostAdr
            // 
            this.lblEpostAdr.AutoSize = true;
            this.lblEpostAdr.Location = new System.Drawing.Point(79, 140);
            this.lblEpostAdr.Name = "lblEpostAdr";
            this.lblEpostAdr.Size = new System.Drawing.Size(62, 15);
            this.lblEpostAdr.TabIndex = 4;
            this.lblEpostAdr.Text = "E-postadress: ";
            // 
            // tbxFöretagNm
            // 
            this.tbxFöretagNm.Location = new System.Drawing.Point(211, 20);
            this.tbxFöretagNm.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbxFöretagNm.Name = "tbxFöretagNm";
            this.tbxFöretagNm.Size = new System.Drawing.Size(160, 23);
            this.tbxFöretagNm.TabIndex = 5;
            // 
            // tbxOrganisationNr
            // 
            this.tbxOrganisationNr.Location = new System.Drawing.Point(211, 50);
            this.tbxOrganisationNr.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbxOrganisationNr.Name = "tbxOrganisationNr";
            this.tbxOrganisationNr.Size = new System.Drawing.Size(160, 23);
            this.tbxOrganisationNr.TabIndex = 6;
            // 
            // tbxKontaktPers
            // 
            this.tbxKontaktPers.Location = new System.Drawing.Point(211, 80);
            this.tbxKontaktPers.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbxKontaktPers.Name = "tbxKontaktPers";
            this.tbxKontaktPers.Size = new System.Drawing.Size(160, 23);
            this.tbxKontaktPers.TabIndex = 7;
            // 
            // tbxTelefonNr
            // 
            this.tbxTelefonNr.Location = new System.Drawing.Point(211, 110);
            this.tbxTelefonNr.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbxTelefonNr.Name = "tbxTelefonNr";
            this.tbxTelefonNr.Size = new System.Drawing.Size(160, 23);
            this.tbxTelefonNr.TabIndex = 8;
            // 
            // tbxEpostAdr
            // 
            this.tbxEpostAdr.Location = new System.Drawing.Point(211, 140);
            this.tbxEpostAdr.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbxEpostAdr.Name = "tbxEpostAdr";
            this.tbxEpostAdr.Size = new System.Drawing.Size(160, 23);
            this.tbxEpostAdr.TabIndex = 9;
            // 
            // btnläggtill
            // 
            this.btnLäggTill.Location = new System.Drawing.Point(211, 175);
            this.btnLäggTill.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnLäggTill.Name = "btnLäggTill";
            this.btnLäggTill.Size = new System.Drawing.Size(159, 23);
            this.btnLäggTill.TabIndex = 10;
            this.btnLäggTill.Text = "Lägg till";
            this.btnLäggTill.UseVisualStyleBackColor = true;
            // 
            // FormInloggning
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(467, 214);
            this.Controls.Add(this.lblInfo);
            this.Controls.Add(this.btnLäggTill);
            this.Controls.Add(this.tbxOrganisationNr);
            this.Controls.Add(this.tbxFöretagNm);
            this.Controls.Add(this.tbxKontaktPers);
            this.Controls.Add(this.tbxTelefonNr);
            this.Controls.Add(this.tbxEpostAdr);
            this.Controls.Add(this.lblOrganisationNr);
            this.Controls.Add(this.lblFöretagNm);
            this.Controls.Add(this.lblKontaktPers);
            this.Controls.Add(this.lblTelefonNr);
            this.Controls.Add(this.lblEpostAdr);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "FormInloggning";
            this.Text = "Registrera ny företagskund";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblInfo;
        private System.Windows.Forms.Label lblFöretagNm;
        private System.Windows.Forms.Label lblOrganisationNr;
        private System.Windows.Forms.Label lblKontaktPers;
        private System.Windows.Forms.Label lblTelefonNr;
        private System.Windows.Forms.Label lblEpostAdr;
        private System.Windows.Forms.TextBox tbxFöretagNm;
        private System.Windows.Forms.TextBox tbxOrganisationNr;
        private System.Windows.Forms.TextBox tbxKontaktPers;
        private System.Windows.Forms.TextBox tbxEpostAdr;
        private System.Windows.Forms.TextBox tbxTelefonNr;
        private System.Windows.Forms.Button btnLäggTill;
    }
}