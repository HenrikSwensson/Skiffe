﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Entiteter;
using Datalager;
using Affärslager;

namespace WinFormsPresentationslager
{

    public partial class FormArtikelhantering : Form
    {
        private SkicenterKontroller skicenterKontroller;
        private UnitOfWork unitOfWork;
        private Anställd Inloggad;
        public FormArtikelhantering(SkicenterKontroller lKontroller, Anställd inloggad)
        {
            InitializeComponent();
            this.skicenterKontroller = lKontroller;
            this.Inloggad = inloggad;
        }

        private void btnTillbakaArtikel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void FormArtikelhantering_Load(object sender, EventArgs e)
        {

        }

        private void btnLäggaTillArtikel_Click(object sender, EventArgs e)
        {
            FormLäggaTillArtikel formLäggaTillArtikel = new FormLäggaTillArtikel(skicenterKontroller, Inloggad);
            formLäggaTillArtikel.Show();
        }
    }
}
