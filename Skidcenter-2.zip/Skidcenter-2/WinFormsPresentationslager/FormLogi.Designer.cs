﻿
namespace WinFormsPresentationslager
{
    partial class FormLogi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code
        private void InitializeComponent()
        {
            this.btnBokaLägenhet = new System.Windows.Forms.Button();
            this.btnAvBokaLägenhet = new System.Windows.Forms.Button();
            this.btnAvsluta = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.btnBokaKonferens = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnBokaLägenhet
            // 
            this.btnBokaLägenhet.Location = new System.Drawing.Point(148, 31);
            this.btnBokaLägenhet.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnBokaLägenhet.Name = "btnBokaLägenhet";
            this.btnBokaLägenhet.Size = new System.Drawing.Size(169, 22);
            this.btnBokaLägenhet.TabIndex = 1;
            this.btnBokaLägenhet.Text = "Lägenhets bokning";
            this.btnBokaLägenhet.UseVisualStyleBackColor = true;
            this.btnBokaLägenhet.Click += new System.EventHandler(this.btnBokaLägenhet_Click);
            // 
            // btnAvBokaLägenhet
            // 
            this.btnAvBokaLägenhet.Location = new System.Drawing.Point(148, 105);
            this.btnAvBokaLägenhet.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnAvBokaLägenhet.Name = "btnAvBokaLägenhet";
            this.btnAvBokaLägenhet.Size = new System.Drawing.Size(169, 22);
            this.btnAvBokaLägenhet.TabIndex = 2;
            this.btnAvBokaLägenhet.Text = "Avboka lägenhet";
            this.btnAvBokaLägenhet.UseVisualStyleBackColor = true;
            this.btnAvBokaLägenhet.Click += new System.EventHandler(this.btnAvBokaLägenhet_Click);
            // 
            // btnAvsluta
            // 
            this.btnAvsluta.Location = new System.Drawing.Point(355, 124);
            this.btnAvsluta.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnAvsluta.Name = "btnAvsluta";
            this.btnAvsluta.Size = new System.Drawing.Size(109, 22);
            this.btnAvsluta.TabIndex = 5;
            this.btnAvsluta.Text = "Tillbaka";
            this.btnAvsluta.UseVisualStyleBackColor = true;
            this.btnAvsluta.Click += new System.EventHandler(this.btnAvsluta_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(41, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 15);
            this.label1.TabIndex = 6;
            this.label1.Text = "Boka Logi";
            // 
            // button1
            // 
            this.btnBokaKonferens.Location = new System.Drawing.Point(148, 67);
            this.btnBokaKonferens.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnBokaKonferens.Name = "button1";
            this.btnBokaKonferens.Size = new System.Drawing.Size(169, 22);
            this.btnBokaKonferens.TabIndex = 7;
            this.btnBokaKonferens.Text = "Konferensrums bokning";
            this.btnBokaKonferens.UseVisualStyleBackColor = true;
            this.btnBokaKonferens.Click += new System.EventHandler(this.btnBokaKonferens_Click);
            // 
            // FormLogi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(467, 157);
            this.Controls.Add(this.btnBokaKonferens);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnAvBokaLägenhet);
            this.Controls.Add(this.btnBokaLägenhet);
            this.Controls.Add(this.btnAvsluta);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "FormLogi";
            this.Text = "Skicenter meny logi";
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        /// </summary>

        private System.Windows.Forms.Button btnBokaLägenhet;
        private System.Windows.Forms.Button btnAvBokaLägenhet;
        private System.Windows.Forms.Button btnAvsluta;
        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnBokaKonferens;
    }
}