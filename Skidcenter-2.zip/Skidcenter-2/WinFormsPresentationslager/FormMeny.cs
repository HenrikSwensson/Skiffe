﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entiteter;
using Affärslager;
using Datalager;

namespace WinFormsPresentationslager
{
    public partial class FormMeny : Form
    {
        private SkicenterKontroller skicenterKontroller;
        private Anställd Inloggad { get; set; }
        public FormMeny(SkicenterKontroller bK)
        {
            InitializeComponent();
            this.skicenterKontroller = bK;
        }

        //private void btnBokaLägenhet_Click(object sender, EventArgs e)
        //{
        //    FormBokaLägenhet formBokaLägenhet = new FormBokaLägenhet(skicenterKontroller, Inloggad);
        //    formBokaLägenhet.Show();
        //}

        //private void btnAvBokaLägenhet_Click(object sender, EventArgs e)
        //{
        //    FormAvBokaLägenhet formAvBokaBok = new FormAvBokaLägenhet(skicenterKontroller, Inloggad);
        //    formAvBokaBok.Show();
        //}

        private void btnLogi_Click(object sender, EventArgs e)
        {
            FormLogi formLogi = new FormLogi(skicenterKontroller, Inloggad);
            formLogi.Show();
        }
        private void btnLoggaUt_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnArtikelhantering_Click(object sender, EventArgs e)
        {
            FormArtikelhantering formArtikelhantering = new FormArtikelhantering(skicenterKontroller, Inloggad);
            formArtikelhantering.Show();
        }

        private void btnLäggTillFöretagskund_Click(object sender, EventArgs e)
        {
            LäggTillFöretagskund formläggtillFöretagskund = new LäggTillFöretagskund();
            formläggtillFöretagskund.Show();
        }
    }
}
