﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Entiteter;
using Affärslager;
using Datalager;

namespace WinFormsPresentationslager
{
    public partial class FormAvBokaLägenhet : Form
    {
        private SkicenterKontroller skicenterKontroller;
        private UnitOfWork unitOfWork;
        private Privatkund Beställare { get; set; }
        private Anställd Inloggad;

        public FormAvBokaLägenhet(SkicenterKontroller bKontroller, Anställd inloggad)
        {
            InitializeComponent();
            this.skicenterKontroller = bKontroller;
            this.Inloggad = inloggad;
        }

        private void btnAvboka_Click(object sender, EventArgs e)
        {
            string nrToParse = "";
            int nr;
            while (!int.TryParse(nrToParse, out nr))
            {
                nrToParse = tbxBokningnr.Text;
            }
            BokningLägenhet attAvboka = skicenterKontroller.KontrollaBokningNr(nr);

            //lblDuAvbokar.Text = "Du Avbokar " + attAvboka.Lägenhet.Beskrivning;

           skicenterKontroller.AvBokaLägenhet(attAvboka);

            lblAvBokadLägenhet.Text = "Avbokad Lägenhet: " + attAvboka.Lägenhet.Beskrivning;
            lblBokadTillPerson.Text = "Bokad till person: " + attAvboka.Privatkund.Namn + " " + attAvboka.Privatkund.Efternamn;
            //lblBokadFrån.Text = "Bokad från: " + Bokning.FaktiskUtlämningstid;
            //lblBokadTill.Text = "Bokad till: " + faktura.FaktiskÅterlämingstid;
            //lblBetalningsskyldig.Text = "Betalningsskyldig: " + faktura.TotalPris + " kr.";
        }

        private void btnAvsluta_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
