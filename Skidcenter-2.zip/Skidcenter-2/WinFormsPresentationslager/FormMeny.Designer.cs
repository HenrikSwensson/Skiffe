﻿
namespace WinFormsPresentationslager
{
    partial class FormMeny
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblValkommen = new System.Windows.Forms.Label();
            this.btnLoggaUt = new System.Windows.Forms.Button();
            this.btnArtikelhantering = new System.Windows.Forms.Button();
            this.btnLogi = new System.Windows.Forms.Button();
            this.btnLäggTillFöretagskund = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblValkommen
            // 
            this.lblValkommen.AutoSize = true;
            this.lblValkommen.Location = new System.Drawing.Point(148, 5);
            this.lblValkommen.Name = "lblValkommen";
            this.lblValkommen.Size = new System.Drawing.Size(151, 15);
            this.lblValkommen.TabIndex = 0;
            this.lblValkommen.Text = "Välkommen till Skidcentret!";
            // 
            // btnLoggaUt
            // 
            this.btnLoggaUt.Location = new System.Drawing.Point(318, 124);
            this.btnLoggaUt.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnLoggaUt.Name = "btnLoggaUt";
            this.btnLoggaUt.Size = new System.Drawing.Size(137, 22);
            this.btnLoggaUt.TabIndex = 3;
            this.btnLoggaUt.Text = "Logga ut";
            this.btnLoggaUt.UseVisualStyleBackColor = true;
            this.btnLoggaUt.Click += new System.EventHandler(this.btnLoggaUt_Click);
            // 
            // btnArtikelhantering
            // 
            this.btnArtikelhantering.Location = new System.Drawing.Point(2, 36);
            this.btnArtikelhantering.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnArtikelhantering.Name = "btnArtikelhantering";
            this.btnArtikelhantering.Size = new System.Drawing.Size(169, 22);
            this.btnArtikelhantering.TabIndex = 4;
            this.btnArtikelhantering.Text = "Artikelhantering";
            this.btnArtikelhantering.UseVisualStyleBackColor = true;
            this.btnArtikelhantering.Click += new System.EventHandler(this.btnArtikelhantering_Click);
            // 
            // btnLogi
            // 
            this.btnLogi.Location = new System.Drawing.Point(228, 85);
            this.btnLogi.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnLogi.Name = "btnLogi";
            this.btnLogi.Size = new System.Drawing.Size(169, 22);
            this.btnLogi.TabIndex = 1;
            this.btnLogi.Text = "Logi";
            this.btnLogi.UseVisualStyleBackColor = true;
            this.btnLogi.Click += new System.EventHandler(this.btnLogi_Click);
            // 
            // btnLäggTillFöretagskund
            // 
            this.btnLäggTillFöretagskund.Location = new System.Drawing.Point(2, 85);
            this.btnLäggTillFöretagskund.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnLäggTillFöretagskund.Name = "btnLäggTillFöretagskund";
            this.btnLäggTillFöretagskund.Size = new System.Drawing.Size(169, 22);
            this.btnLäggTillFöretagskund.TabIndex = 4;
            this.btnLäggTillFöretagskund.Text = "Registrera Företagskund";
            this.btnLäggTillFöretagskund.UseVisualStyleBackColor = true;
            this.btnLäggTillFöretagskund.Click += new System.EventHandler(this.btnLäggTillFöretagskund_Click);
            // 
            // FormMeny
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(467, 157);
            this.Controls.Add(this.btnArtikelhantering);
            this.Controls.Add(this.btnLäggTillFöretagskund);
            this.Controls.Add(this.btnLoggaUt);
            this.Controls.Add(this.btnLogi);
            this.Controls.Add(this.lblValkommen);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "FormMeny";
            this.Text = "Skicenter meny";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblValkommen;
        private System.Windows.Forms.Button btnLoggaUt;
        private System.Windows.Forms.Button btnArtikelhantering;
        private System.Windows.Forms.Button btnLogi;
        private System.Windows.Forms.Button btnLäggTillFöretagskund;
        private System.Windows.Forms.Button btnLäggTillPrivatkund;
    }
}