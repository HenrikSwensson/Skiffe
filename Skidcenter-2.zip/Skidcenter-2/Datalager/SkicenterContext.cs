﻿using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System;
using Microsoft.Extensions.Configuration;
using Entiteter;
using System.IO;

namespace Datalager
{
    public class SkicenterContext : DbContext
    {
        public DbSet<Artikel> Artiklar { get; set; }
        public DbSet<Privatkund> Privatkunder { get; set; }
        public DbSet<Foretagskund> Företagskunder { get; set; }
        public DbSet<Bokning> Bokningar { get; set; }
        public DbSet<BokningLägenhet> BokningarLägenhet { get; set; }
        public DbSet<BokningKonferensrum> BokningarKonferensrum { get; set; }
        public DbSet<Lägenhet> Lägenheter { get; set; }
        public DbSet<Anställd> Anställda { get; set; }
        public DbSet<Konferensrum> Konferensrummen { get; set; }
        public DbSet<Uthyrningslogg> Uthyrningslogg { get; set; }
        //public DbSet<Faktura> Fakturor { get; set; }

        public SkicenterContext()
        {
            Seed(); //uncomment to (re)create database & fill/seed example data
        }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
             optionsBuilder.UseSqlServer(@"Server = (localdb)\mssqllocaldb; Database = Skicenter; Integrated Security = True");

            //optionsBuilder.UseSqlServer(new ConfigurationBuilder()
            //       .SetBasePath(Directory.GetCurrentDirectory())
            //       .AddJsonFile("appsettings.json", true, true) //appsettings.json typically used for entityframeworkcore
            //       .Build()                                     //don't forget set "copy if newer" on appsettings.json to be included in build 
            //       .GetConnectionString("Bokproj"));
            base.OnConfiguring(optionsBuilder);
        }

        public void Seed()
        {
            Database.EnsureDeleted();
            Reset();
            Database.EnsureCreated();


            Artikel a1 = new Artikel("3ap", false, "Pjäxor");
            Artiklar.Add(a1);

            Foretagskund f1 = new Foretagskund("Nisse") { OrgNr = "123", KontaktPerson = "Niklas Nissesson", TlfNr = "874613152", Epostadress = "Student.student@student.se" };
            Företagskunder.Add(f1);
         

            Privatkund p1 = new Privatkund("Johan") { Efternamn = "Johansson", TlfNr = "070875786", Epostadress = "Johan@gmail.com" };
            Privatkunder.Add(p1);

            Privatkund p2 = new Privatkund("Johanna") { Efternamn = "Persson", TlfNr = "070875786", Epostadress = "Johan@gmail.com" };
            Privatkunder.Add(p2);

            Privatkund p3 = new Privatkund("Josefin") { Efternamn = "Olsson", TlfNr = "070875786", Epostadress = "Johan@gmail.com" };
            Privatkunder.Add(p3);
            Privatkund p4 = new Privatkund("Adam") { Efternamn = "Karlsson", TlfNr = "070875786", Epostadress = "Johan@gmail.com" };
            Privatkunder.Add(p4);

            Lägenhet l1 = new Lägenhet("LI1", true, "Storlägenhet", 330);
            Lägenhet l4 = new Lägenhet("LI2", false, "Storlägenhet", 330);
            Lägenheter.Add(l4);
            Lägenhet l5 = new Lägenhet("LI3", false, "Storlägenhet", 330);
            Lägenheter.Add(l5);

            Lägenheter.Add(l1);
            Lägenhet l2 = new Lägenhet("LII1", true, "Litenlägenhet", 240);
            Lägenheter.Add(l2);
            Lägenhet l3 = new Lägenhet("LII2", true, "Litenlägenhet", 240);
            Lägenheter.Add(l3);
            Lägenhet l6 = new Lägenhet("LII3", true, "Litenlägenhet", 240);
            Lägenheter.Add(l6);


            Konferensrum k1 = new Konferensrum("KLS1", true, "StortKonferensrum", 1200);
            Konferensrummen.Add(k1);
            Konferensrum k2 = new Konferensrum("KLS2", true, "StortKonferensrum", 850);
            Konferensrummen.Add(k2);
            Konferensrum k3 = new Konferensrum("KLS3", true, "StortKonferensrum", 850);
            Konferensrummen.Add(k3);

            Konferensrum k4 = new Konferensrum("KLL1", true, "LitetKonferensrum", 850);
            Konferensrummen.Add(k4);

            Konferensrum k5 = new Konferensrum("KLL2", true, "LitetKonferensrum", 850);
            Konferensrummen.Add(k5);




            Anställda.Add(new Anställd("Johan") { AnvändarNamn = "Johan1", Lösenord = "Johan100", Roll = RollTyp.Admin  });
            Anställd an1 = new Anställd("Anna") { AnvändarNamn = "Anna1", Lösenord = "Anna100", Roll = RollTyp.Bokningsansvarig };
            Anställda.Add(an1);
            Anställd an2 = new Anställd("Fredrik") {  AnvändarNamn = "Fredrik1", Lösenord = "Fredrik100", Roll = RollTyp.Marknadschef };
            Anställda.Add(an2);

           // Bokning bg1 = new Bokning(p1, l1, DateTime.Now, DateTime.Now, DateTime.Now - TimeSpan.FromDays(60));
           //Bokningar.Add(bg1);
            //Bokning bg2 = new Bokning(m2, b1, e2, DateTime.Now, DateTime.Now, DateTime.Now - TimeSpan.FromDays(15));
            //Bokningar.Add(bg2);

            //Faktura f1 = new Faktura(bg1, DateTime.Now, e1);
            //Fakturor.Add(f1);
            //Faktura f2 = new Faktura(bg2, DateTime.Now, e1);
            //Fakturor.Add(f2);

            SaveChanges();
        }


        public void Reset()

        {

            for (int i = 0; i < 5; i++)

            {

                try
                {


                    Database.ExecuteSqlRaw("EXEC sp_MSforeachtable 'ALTER TABLE ? NOCHECK CONSTRAINT ALL'");
                    Database.ExecuteSqlRaw("EXEC sp_MSforeachtable 'DROP TABLE ?'");


                }
                catch (System.Exception)

                { }
            }


        }



    }

}