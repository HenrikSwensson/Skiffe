﻿using System;
using System.Collections.Generic;
using Entiteter;

namespace Datalager
{
    /// <summary>
    ///  This class is used to access the storage in the application.
    /// </summary>
    public class UnitOfWork
    {
        private SkicenterContext context;
        public Repository<Foretagskund> FöretagskundRepository { get; private set; }
        public Repository<Privatkund> PrivatkundRepository { get; private set; }
        public Repository<Lägenhet> LägenhetRepository { get; private set; }
        public Repository<Anställd> AnställdRepository { get; private set; }
        public Repository<Artikel> ArtiklarRepository { get; private set; }
        public Repository<Bokning> BokningRepository { get; private set; }
        public Repository<BokningLägenhet> BokningLägenhetRepository { get; private set; }
        public Repository<BokningKonferensrum> BokningKonferensrumRepository { get; private set; }
        public Repository<Konferensrum> KonferensrumRepository { get; private set; }

        //public Repository<Faktura> FakturaRepository { get; private set; }

        /// <summary>
        ///  Create a new instance.
        /// </summary>
        public UnitOfWork()
        {
            context = new SkicenterContext();
            FöretagskundRepository = new Repository<Foretagskund>(context);
            PrivatkundRepository = new Repository<Privatkund>(context);
           LägenhetRepository = new Repository<Lägenhet>(context);
            AnställdRepository = new Repository<Anställd>(context);
            ArtiklarRepository = new Repository<Artikel>(context);
            BokningRepository = new Repository<Bokning>(context);
            BokningLägenhetRepository = new Repository<BokningLägenhet>(context);
            BokningKonferensrumRepository = new Repository<BokningKonferensrum>(context);
            KonferensrumRepository = new Repository<Konferensrum>(context);

            //FakturaRepository = new Repository<Faktura>(context);
        }

        /// <summary>
        ///  Save the changes made.
        /// </summary>
        public void Save()
        {
            context.SaveChanges();
        }
    }
}