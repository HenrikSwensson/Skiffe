﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Entiteter
{
    public class Lägenhet
    {
        [Key]
        public int LägenhetsID { get; set; }
       public string ArtikelNr { get; set; }
        public bool Tillgänglig { get; set; }
        public string Beskrivning { get; set; }
        public int Pris { get; set; }


        public Lägenhet(string artikelnr, bool tillgänglig, string beskrivnig, int pris)
        {
            ArtikelNr = artikelnr;
            Beskrivning = beskrivnig;
            Tillgänglig = tillgänglig;
            Pris = pris;
        }

        private Lägenhet() { }
    }
}
