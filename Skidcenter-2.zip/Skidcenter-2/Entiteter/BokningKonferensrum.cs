﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entiteter
{
    public class BokningKonferensrum : Bokning
    {

        public Konferensrum Konferensrum { get; set; }

        public BokningKonferensrum(Privatkund privatkund, Konferensrum konferensrum, DateTime tilltänktUtlämingstid, DateTime faktiskUtlämningstid,
        DateTime tilltänktaÅterlämningstid)
        {
            Privatkund = privatkund;
            Konferensrum = konferensrum;
            TilltänktUtlämningstid = tilltänktUtlämingstid;
            FaktiskUtlämningstid = faktiskUtlämningstid;
            TilltänktaÅterlämningstid = tilltänktaÅterlämningstid;

        }


        private BokningKonferensrum() { }
    }
}
