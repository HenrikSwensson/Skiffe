﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Entiteter
{
    public enum RollTyp
    {
        Admin,
        Bokningsansvarig,
        Marknadschef
        // etc...
    }
    public class Anställd : Person
    {

        [Key]
        public int AnställningID { get; set; }
        public string AnvändarNamn { get; set; }
        public string Lösenord { get; set; }
        public RollTyp Roll { get; set; }

        public Anställd(string namn)
             : base(namn)
        {
            Namn = namn;
        }


        public bool VerifieraLösenord(string angett)
        {
            return Lösenord == angett;
        }

        private Anställd() { }
    }

}
