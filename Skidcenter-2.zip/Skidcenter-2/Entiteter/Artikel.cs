﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Entiteter
{
    public class Artikel
    {

        [Key]
        public int ArtikelID { get; set; }
        public string ArtikelNr { get; set; }
        public bool Tillgänglig { get; set; }
        public string Beskrivning { get; set; }

        public Artikel(string artikelnr, bool tillgänglig, string beskrivnig)
        {
            ArtikelNr = artikelnr;
            Beskrivning = beskrivnig;
            Tillgänglig = tillgänglig;
        }

        private Artikel() { }
    }
}
