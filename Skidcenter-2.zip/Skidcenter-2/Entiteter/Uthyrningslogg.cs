﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Entiteter
{
    public class Uthyrningslogg
    {

        [Key]

        public int BokningsNummer { get; set; }      
        public int ArtikelId { get; set; }     //ref till artikeln
        public DateTime Datum { get; set; }
        public int Antal { get; set; }
    } 
    
    
}
