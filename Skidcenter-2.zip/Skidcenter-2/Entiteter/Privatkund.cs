﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Entiteter
{
    public class Privatkund : Person 
    {

        [Key]
        public int KundID { get; set; }
      public string Efternamn { get; set; }
        public int PersonNr { get; set; }
        public string TlfNr { get; set; }
        public string Epostadress { get; set; }


        [NotMapped]
        public Bokning Bokad
        {
            // This is not very good if we had a real database. Search the database instead.
            // Edit: now done in CarPoolBL!
            get; set;
        }
        public Privatkund(string namn) : base(namn)
        {
            Namn = namn;
        }
        private Privatkund() { }
    }
}
