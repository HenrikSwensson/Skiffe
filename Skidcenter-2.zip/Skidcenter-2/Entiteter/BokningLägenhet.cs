﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entiteter
{
    public class BokningLägenhet : Bokning
    {

        public Lägenhet Lägenhet { get; set; }

        public BokningLägenhet(Privatkund privatkund, Lägenhet lägenhet, DateTime tilltänktUtlämingstid, DateTime faktiskUtlämningstid,
        DateTime tilltänktaÅterlämningstid)
        {
            Privatkund = privatkund;
            Lägenhet = lägenhet;
            TilltänktUtlämningstid = tilltänktUtlämingstid;
            FaktiskUtlämningstid = faktiskUtlämningstid;
            TilltänktaÅterlämningstid = tilltänktaÅterlämningstid;

        }


        private BokningLägenhet() { }
    }
}
