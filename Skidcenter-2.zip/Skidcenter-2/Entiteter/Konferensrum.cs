﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Entiteter
{
   public class Konferensrum
    {
        [Key]
        public int KonferensID { get; set; }
        public string ArtikelNr { get; set; }
        public bool Tillgänglig { get; set; }
        public string Beskrivning { get; set; }
        public int Pris { get; set; }


        public Konferensrum(string artikelnr, bool tillgänglig, string beskrivnig, int pris)
        {
            ArtikelNr = artikelnr;
            Beskrivning = beskrivnig;
            Tillgänglig = tillgänglig;
            Pris = pris;
        }

        private Konferensrum() { }
    }
}
