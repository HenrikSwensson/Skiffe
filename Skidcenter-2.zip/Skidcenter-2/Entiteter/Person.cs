﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entiteter
{
    public class Person
    {
        public string Namn { get; set; }

        public Person(string namn)
        {
            Namn = namn;
        }

        public Person() { }
    }
}