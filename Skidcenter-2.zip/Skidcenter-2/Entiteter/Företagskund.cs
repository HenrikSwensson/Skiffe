﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Entiteter
{
    public class Foretagskund : Person 
    {

        [Key]
        public string OrgNr { get; set; }
        public string KontaktPerson { get; set; }
        public string TlfNr { get; set; }
        public string Epostadress { get; set; }


        [NotMapped]
        public Bokning Bokad
        {
            // This is not very good if we had a real database. Search the database instead.
            // Edit: now done in CarPoolBL!
            get; set;
        }
        public Foretagskund(string namn) : base(namn)
        {
            Namn = namn;
        }
        public Foretagskund() { }
    }
}
