﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;
namespace Entiteter
{
    public class Bokning
    {
        [Key]
    public int BokningsID { get; set; }

    public Privatkund Privatkund { get; set; }
   
  
        public DateTime TilltänktUtlämningstid { get; set; }
    public DateTime FaktiskUtlämningstid { get; set; }
    public DateTime TilltänktaÅterlämningstid { get; set; }

    

        //private Bokning() { }
    }
}
