﻿using Datalager;
using Entiteter;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Affärslager
{
    public class ArtikelKontroller
    {
    }
}