﻿using Datalager;
using Entiteter;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Affärslager
{
    public class SkicenterKontroller
    {
        private Datalager.UnitOfWork unitOfWork;
        public Anställd Inloggad { get; private set; }
        public Privatkund Beställare { get; set; }
       public BokningLägenhet Bokningen { get; private set; }
        public BokningKonferensrum Bokningen2 { get; private set; }


        

        /// <summary>
        /// Logga in-funktion.
        /// </summary>
        /// <param name="memberId"></param>
        /// <param name="lösenord"></param>
        /// <returns></returns>
        public bool LoggaIn(string användarNamn, string lösenord)
        {
            unitOfWork = new Datalager.UnitOfWork();
            Anställd e = unitOfWork.AnställdRepository.FirstOrDefault(e => e.AnvändarNamn == användarNamn);

            if (e != null && e.VerifieraLösenord(lösenord))
            {
                Inloggad = e;

                return true;
            }

            Inloggad = null;
            return false;
        }
        public Anställd HämtaInloggadAnställd()
        {
            return Inloggad; // Antagande att Inloggad är en variabel av typen Anställd.
        }


        /// <summary>
        /// Kontrollerar att det inmatade medlemsnumret är en befintlig medlem. 
        /// </summary>
        /// <param name="nr"></param>
        /// <returns></returns>


        public Privatkund KontrolleraKund(int nr)
        {
            Privatkund beställare = unitOfWork.PrivatkundRepository.FirstOrDefault(p => p.KundID == nr);
            if (beställare != null)
            {
                Beställare = beställare;
                return Beställare;
            }
            Beställare = null;
            return null;
        }
        public bool LaggTillForetagskund(Foretagskund nyForetagskund)
        {
            // Validation: Check if the object or critical properties are null
            if (nyForetagskund == null || string.IsNullOrEmpty(nyForetagskund.Namn) /* Add other property checks here */)
            {
                // Log or print out an error message
                return false;
            }

            try
            {
                // Using UnitOfWork to add the new Foretagskund to the database
                unitOfWork.FöretagskundRepository.Add(nyForetagskund);

                // Committing the transaction
                unitOfWork.Save();

                return true;
            }
            catch (Exception ex)
            {
                // Log the exception, you might want to print it or save it in a log file
                Console.WriteLine(ex.Message);

                return false;
            }
        }




        /// <summary>
        /// Hämta lägenheter som är tillgängliga för bokning.
        /// </summary>
        /// <returns></returns>
        public IList<Lägenhet> HämtaTillgängligaLägenheter()
        {
            if (Inloggad == null)
            {
                throw new ApplicationException("Ingen är inloggad.");
            }



            List<Lägenhet> tillgägnligaLägenheter = new List<Lägenhet>();
            foreach (Lägenhet l in unitOfWork.LägenhetRepository.Find(l => l.Tillgänglig))
            {
                tillgägnligaLägenheter.Add(l);
            }
            return tillgägnligaLägenheter;
        }

        // Hämtar tillgängliga konferensrum
        public IList<Konferensrum> HämtaTillgängligaKonferensrum()
        {
            if (Inloggad == null)
            {
                throw new ApplicationException("Ingen är inloggad.");
            }



            List<Konferensrum> tillgägnligaKonferensrum = new List<Konferensrum>();
            foreach (Konferensrum l in unitOfWork.KonferensrumRepository.Find(l => l.Tillgänglig))
            {
                tillgägnligaKonferensrum.Add(l);
            }
            return tillgägnligaKonferensrum;
        }

        ///// <summary>
        ///// Boka en lägenhet.
        ///// </summary>

        ///// <returns>the reservation.</returns>
       

        public BokningLägenhet BokaLägenhet(Lägenhet lägenhet, DateTime frånTid, DateTime tillTid)
        {
            if (Inloggad == null)
            {
                throw new ApplicationException("Ingen är inloggad.");
            }
            //if (!bok.Tillgänglig)
            //{
            //    throw new ApplicationException("Boken " + bok.Titel + " är redan bokad av någon annan.");
            //}
            lägenhet.Tillgänglig = false;
            BokningLägenhet bokning = new BokningLägenhet(Beställare, lägenhet, frånTid, frånTid, tillTid);
            unitOfWork.BokningRepository.Add(bokning);
            Beställare.Bokad = bokning;
            unitOfWork.Save();

            return bokning;
        }


        //Bokning av konferensrum
        public BokningKonferensrum BokaKonferensrum(Konferensrum konferensrum, DateTime frånTid, DateTime tillTid)
        {
            if (Inloggad == null)
            {
                throw new ApplicationException("Ingen är inloggad.");
            }
        
            konferensrum.Tillgänglig = false;
            BokningKonferensrum bokning = new BokningKonferensrum(Beställare, konferensrum, frånTid, frånTid, tillTid);
            unitOfWork.BokningRepository.Add(bokning);
            Beställare.Bokad = bokning;
            unitOfWork.Save();

            return bokning;
        }

        /// <summary>
        /// Kontrollerar att bokningsnumret stämmer med befintlig bokning.
        /// </summary>
        /// <param name="nr"></param>
        /// <returns></returns>
        public BokningLägenhet KontrollaBokningNr(int nr)
        {
            BokningLägenhet bokningNr = unitOfWork.BokningLägenhetRepository.FirstOrDefault(k => k.BokningsID == nr);
            if (bokningNr != null)
            {
                Bokningen = bokningNr;
                return Bokningen;
            }
            Bokningen = null;
            return null;
        }

        // Kontrollerar bokningsnummer Konferensrum
        public BokningKonferensrum KontrollaBokningNR(int nr)
        {
            BokningKonferensrum bokningNr = unitOfWork.BokningKonferensrumRepository.FirstOrDefault(k => k.BokningsID == nr);
            if (bokningNr != null)
            {
                Bokningen2 = bokningNr;
                return Bokningen2;
            }
            Bokningen2 = null;
            return null;
        }
        ///// <summary>
        ///// Avboka en lägenhet
        ///// <returns>the invoice.</returns>
        public BokningLägenhet AvBokaLägenhet(BokningLägenhet bokning)
        {
            if (Inloggad == null)
            {
                throw new ApplicationException("Ingen är inloggad.");
            }
            //if (Beställare.Bokningen == null)
            //{
            //    throw new ApplicationException("Det finns inga bokningar.");
            //}


            bokning.Lägenhet.Tillgänglig = true;
            unitOfWork.Save();

            return bokning;
        }

        public BokningLägenhet Bokad()
        {
            return unitOfWork.BokningLägenhetRepository.FirstOrDefault( //lambda expression
                        r => r.Privatkund.KundID == Inloggad.AnställningID && r.TilltänktaÅterlämningstid == null, r => r.Privatkund, r => r.Lägenhet);
            //seraches for reservations that matches the current logged-in member, AND from those that has a reservation end-time "To" not set yet (=active reservation)
            //r => r.Member, r => r.Car    means we load/"include" these for use now or later (you will notice otherwise if getting "nullreferenceexceptions")

        }

        // private Datalager.UnitOfWork unitOfWork; // Bortkommenterad då vi inte fick den att funka
    }
}
